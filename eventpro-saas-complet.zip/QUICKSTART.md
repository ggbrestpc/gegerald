# 🚀 Guide de Démarrage Rapide EventPro SaaS

## ⚡ Installation en 5 Minutes (Cloud - Recommandé)

### Prérequis
- Compte GitHub (gratuit)
- Compte Vercel (gratuit)
- Compte Railway (gratuit)
- Compte MongoDB Atlas (gratuit)

### Étape 1 : MongoDB Atlas (2 min)

1. Allez sur https://www.mongodb.com/cloud/atlas
2. Créez un compte gratuit
3. Créez un cluster M0 (gratuit)
4. Database Access → Add User → Créez un utilisateur
5. Network Access → Add IP → Autoriser `0.0.0.0/0` (toutes IPs)
6. Copiez la **Connection String** : `mongodb+srv://user:password@cluster.mongodb.net`

### Étape 2 : Déployer le Backend sur Railway (1 min)

1. Allez sur https://railway.app
2. Sign Up avec GitHub
3. New Project → Deploy from GitHub Repo
4. Sélectionnez le dossier `backend`
5. Variables d'environnement :
   ```
   MONGO_URL=mongodb+srv://user:pass@cluster.mongodb.net
   DB_NAME=eventpro
   CORS_ORIGINS=*
   JWT_SECRET_KEY=votre-secret-key-super-securise-changez-moi
   ```
6. Copiez l'URL publique : `https://votre-app.railway.app`

### Étape 3 : Déployer le Frontend sur Vercel (1 min)

1. Allez sur https://vercel.com
2. Sign Up avec GitHub
3. New Project → Import Git Repository
4. Sélectionnez le dossier `frontend`
5. Environment Variable :
   ```
   REACT_APP_BACKEND_URL=https://votre-app.railway.app
   ```
6. Deploy !

### Étape 4 : Configuration Stripe (1 min)

1. Créez un compte sur https://stripe.com
2. Mode Test → API Keys
3. Copiez `Publishable key` et `Secret key`
4. Sur Railway, éditez `config.json` via l'interface :
   ```json
   {
     "stripe": {
       "secret_key": "sk_test_...",
       "publishable_key": "pk_test_..."
     }
   }
   ```

### ✅ C'est Prêt !

Votre plateforme est en ligne sur : `https://votre-app.vercel.app`

---

## 💻 Installation en Local (Développement)

### Prérequis
- Node.js 18+
- Python 3.11+
- MongoDB (local ou Atlas)

### Backend

```bash
cd backend

# Créer environnement virtuel
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Installer dépendances
pip install -r requirements.txt

# Configurer .env
cat > .env << EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=eventpro
CORS_ORIGINS=*
JWT_SECRET_KEY=dev-secret-key
EOF

# Lancer
uvicorn server:app --reload
```

Backend disponible sur : http://localhost:8000

### Frontend

```bash
cd frontend

# Installer dépendances
npm install

# Configurer .env
cat > .env << EOF
REACT_APP_BACKEND_URL=http://localhost:8000
EOF

# Lancer
npm start
```

Frontend disponible sur : http://localhost:3000

---

## 🎯 Premier Utilisateur (Super Admin)

### Via MongoDB Compass ou Shell

```javascript
// Se connecter à la base eventpro
use eventpro

// Créer un super admin
db.users.updateOne(
  { "email": "admin@eventpro.com" },
  { 
    $set: { 
      "role": "super_admin",
      "is_active": true
    } 
  }
)
```

Ou via l'API après inscription :

```bash
# S'inscrire normalement sur /register
# Puis via MongoDB, promouvoir en super_admin
```

---

## 🔧 Configuration des Services

### Stripe (Mode Test)

**Clés de test :**
1. Dashboard Stripe → Developers → API Keys
2. Basculer sur "Test mode" (toggle en haut)
3. Copier :
   - `Publishable key` : `pk_test_...`
   - `Secret key` : `sk_test_...`

**Webhooks :**
1. Developers → Webhooks → Add endpoint
2. URL : `https://votre-backend.railway.app/api/payment/webhook`
3. Events : `checkout.session.completed`
4. Copier le `Signing secret` : `whsec_...`

**Cartes de test :**
- Succès : `4242 4242 4242 4242`
- Date : n'importe quelle date future
- CVC : n'importe quel 3 chiffres

### SMTP (Emails)

**Option 1 : Brevo (Gratuit - 300/jour)**
```json
{
  "smtp": {
    "host": "smtp-relay.brevo.com",
    "port": 587,
    "username": "votre-email@example.com",
    "password": "votre-smtp-key",
    "from_email": "noreply@votredomaine.com"
  }
}
```

**Option 2 : Gmail**
```json
{
  "smtp": {
    "host": "smtp.gmail.com",
    "port": 587,
    "username": "votre-email@gmail.com",
    "password": "votre-app-password",
    "from_email": "votre-email@gmail.com"
  }
}
```

---

## 📱 Tester l'Application

### 1. Inscription
- Allez sur `/register`
- Créez un compte
- Redirection automatique vers `/dashboard`

### 2. Créer une Catégorie
- Dashboard → Onglet "Catégories"
- Cliquez "Nouvelle catégorie"
- Nom : "Concert", Couleur : Violet
- Créer

### 3. Créer un Événement
- Dashboard → Onglet "Événements"
- Cliquez "Nouvel événement"
- Remplissez le formulaire
- Créer

### 4. Page Publique
- Accédez à : `/events/votre-slug`
- Vérifiez la billetterie
- Testez le bouton de réservation

### 5. Scanner QR
- Accédez à : `/scanner`
- Entrez un code QR
- Validez

---

## 🐛 Résolution de Problèmes

### Backend ne démarre pas
```bash
# Vérifier Python
python3 --version  # Doit être 3.11+

# Vérifier MongoDB
python3 -c "from pymongo import MongoClient; print(MongoClient('mongodb://localhost:27017').server_info())"

# Voir les logs
tail -f logs/error.log
```

### Frontend erreur CORS
- Vérifiez `CORS_ORIGINS=*` dans backend `.env`
- Redémarrez le backend

### Stripe ne fonctionne pas
- Vérifiez les clés dans `config.json`
- Mode Test activé sur Stripe Dashboard
- Utilisez `4242 4242 4242 4242` pour tester

### MongoDB erreur de connexion
- MongoDB local : `brew services start mongodb-community` (Mac)
- MongoDB Atlas : Vérifiez IP whitelisting

---

## 📚 Ressources

- **Documentation API** : http://localhost:8000/docs (local)
- **Stripe Docs** : https://stripe.com/docs
- **MongoDB Atlas** : https://docs.atlas.mongodb.com
- **Railway** : https://docs.railway.app
- **Vercel** : https://vercel.com/docs

---

## 🎉 Prochaines Étapes

1. ✅ Personnaliser les couleurs dans le dashboard
2. ✅ Créer vos premiers événements
3. ✅ Tester la billetterie Stripe
4. ✅ Scanner des QR codes
5. ✅ Configurer votre domaine personnalisé
6. ✅ Passer en production (Stripe Live Mode)

---

**Besoin d'aide ?** Consultez le README.md complet !

Bon développement ! 🚀
