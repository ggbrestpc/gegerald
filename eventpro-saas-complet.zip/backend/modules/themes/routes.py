# Routes marketplace thèmes
from fastapi import APIRouter, HTTPException, Depends
from typing import List
from ..auth.models import User
from ..auth.routes import get_current_user
from .models import Theme, ThemeCreate, ThemePurchase
from database import db
from datetime import datetime, timezone

router = APIRouter(prefix="/themes", tags=["Themes"])


@router.post("/", response_model=Theme)
async def create_theme(
    theme_data: ThemeCreate,
    current_user: User = Depends(get_current_user)
):
    """Crée un nouveau thème (réservé super admin)"""
    if current_user.role != "super_admin":
        raise HTTPException(status_code=403, detail="Réservé aux super admins")
    
    theme = Theme(
        **theme_data.model_dump(),
        created_by=current_user.id
    )
    
    theme_dict = theme.model_dump()
    theme_dict["created_at"] = theme_dict["created_at"].isoformat()
    
    await db.themes.insert_one(theme_dict)
    return theme


@router.get("/", response_model=List[Theme])
async def get_themes(
    current_user: User = Depends(get_current_user)
):
    """Récupère tous les thèmes disponibles"""
    themes = await db.themes.find({"is_active": True}, {"_id": 0}).to_list(1000)
    return themes


@router.post("/purchase/{theme_id}")
async def purchase_theme(
    theme_id: str,
    current_user: User = Depends(get_current_user)
):
    """Acheter un thème"""
    # Vérifier que le thème existe
    theme = await db.themes.find_one({"id": theme_id}, {"_id": 0})
    if not theme:
        raise HTTPException(status_code=404, detail="Thème non trouvé")
    
    # Vérifier si déjà acheté
    existing_purchase = await db.theme_purchases.find_one({
        "user_id": current_user.id,
        "theme_id": theme_id
    })
    
    if existing_purchase:
        return {"message": "Thème déjà possédé", "already_owned": True}
    
    # Si gratuit, donner directement
    if theme["price"] == 0:
        purchase = ThemePurchase(
            user_id=current_user.id,
            theme_id=theme_id,
            price_paid=0
        )
        
        purchase_dict = purchase.model_dump()
        purchase_dict["purchased_at"] = purchase_dict["purchased_at"].isoformat()
        
        await db.theme_purchases.insert_one(purchase_dict)
        
        # Incrémenter le compteur de téléchargements
        await db.themes.update_one(
            {"id": theme_id},
            {"$inc": {"downloads": 1}}
        )
        
        return {"message": "Thème ajouté à votre bibliothèque", "purchase": purchase}
    
    # Sinon, créer une session Stripe (TODO)
    return {"message": "Paiement requis", "price": theme["price"]}


@router.get("/my-themes", response_model=List[Theme])
async def get_my_themes(
    current_user: User = Depends(get_current_user)
):
    """Récupère les thèmes possédés par l'utilisateur"""
    # Récupérer les achats
    purchases = await db.theme_purchases.find(
        {"user_id": current_user.id},
        {"_id": 0, "theme_id": 1}
    ).to_list(1000)
    
    theme_ids = [p["theme_id"] for p in purchases]
    
    if not theme_ids:
        return []
    
    # Récupérer les thèmes
    themes = await db.themes.find(
        {"id": {"$in": theme_ids}},
        {"_id": 0}
    ).to_list(1000)
    
    return themes
