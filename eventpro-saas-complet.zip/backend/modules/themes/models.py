# Modèles pour les thèmes
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from datetime import datetime, timezone
import uuid


class Theme(BaseModel):
    """Modèle pour un thème"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str
    preview_image: str
    price: float = 0  # 0 = gratuit
    is_premium: bool = False
    colors: dict = {}  # Configuration des couleurs
    css: str = ""  # CSS personnalisé
    is_active: bool = True
    created_by: str = "system"  # "system" ou user_id du créateur
    downloads: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ThemeCreate(BaseModel):
    """Modèle pour créer un thème"""
    name: str
    description: str
    preview_image: str
    price: float = 0
    is_premium: bool = False
    colors: dict = {}
    css: str = ""


class ThemePurchase(BaseModel):
    """Modèle pour l'achat d'un thème"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    theme_id: str
    price_paid: float
    purchased_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
