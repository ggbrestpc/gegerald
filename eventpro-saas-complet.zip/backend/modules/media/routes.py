# Routes pour l'upload et la conversion d'images
from fastapi import APIRouter, HTTPException, UploadFile, File, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase
from PIL import Image
from io import BytesIO
import os
import uuid
from pathlib import Path
from ..auth.models import User
from ..auth.routes import get_current_user

router = APIRouter(prefix="/media", tags=["Media"])

# Répertoire de stockage des médias
MEDIA_DIR = Path("/app/backend/uploads")
MEDIA_DIR.mkdir(exist_ok=True)


@router.post("/upload")
async def upload_image(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """Upload une image et la convertit automatiquement en WebP"""
    # Vérifier le type de fichier
    allowed_types = ["image/jpeg", "image/png", "image/jpg", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Type de fichier non supporté. Utilisez JPEG, PNG ou WebP"
        )
    
    try:
        # Lire le contenu du fichier
        contents = await file.read()
        image = Image.open(BytesIO(contents))
        
        # Générer un nom de fichier unique
        filename = f"{uuid.uuid4()}.webp"
        filepath = MEDIA_DIR / filename
        
        # Convertir et sauvegarder en WebP
        # Optimiser la qualité et la taille
        image.save(filepath, "WebP", quality=85, method=6)
        
        # URL relative pour accéder à l'image
        image_url = f"/api/media/files/{filename}"
        
        return {
            "url": image_url,
            "filename": filename,
            "size": os.path.getsize(filepath),
            "format": "webp"
        }
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Erreur lors du traitement de l'image: {str(e)}")


@router.get("/files/{filename}")
async def get_media_file(filename: str):
    """Récupère un fichier média"""
    from fastapi.responses import FileResponse
    
    filepath = MEDIA_DIR / filename
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="Fichier non trouvé")
    
    return FileResponse(filepath, media_type="image/webp")
