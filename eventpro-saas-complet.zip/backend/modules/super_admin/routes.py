# Routes Super Admin
from fastapi import APIRouter, HTTPException, Depends
from typing import List
from ..auth.models import User, UserRole, Permission
from ..auth.routes import get_current_user
from database import db
from datetime import datetime, timezone

router = APIRouter(prefix="/super-admin", tags=["Super Admin"])


async def require_super_admin(current_user: User = Depends(get_current_user)):
    """Vérifie que l'utilisateur est super admin"""
    if current_user.role != UserRole.SUPER_ADMIN:
        raise HTTPException(status_code=403, detail="Accès réservé aux super admins")
    return current_user


@router.get("/users", response_model=List[User])
async def get_all_users(
    current_user: User = Depends(require_super_admin)
):
    """Récupère tous les utilisateurs"""
    users = await db.users.find({}, {"_id": 0, "hashed_password": 0}).to_list(10000)
    return users


@router.put("/users/{user_id}/permissions")
async def update_user_permissions(
    user_id: str,
    permissions: List[str],
    current_user: User = Depends(require_super_admin)
):
    """Met à jour les permissions d'un utilisateur"""
    # Vérifier que l'utilisateur existe
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    
    # Mettre à jour les permissions
    await db.users.update_one(
        {"id": user_id},
        {"$set": {
            "permissions": permissions,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    return {"message": "Permissions mises à jour", "permissions": permissions}


@router.post("/users/{user_id}/toggle-status")
async def toggle_user_status(
    user_id: str,
    current_user: User = Depends(require_super_admin)
):
    """Active/désactive un utilisateur"""
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    
    new_status = not user.get("is_active", True)
    
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"is_active": new_status}}
    )
    
    return {"message": "Statut mis à jour", "is_active": new_status}


@router.get("/stats")
async def get_platform_stats(
    current_user: User = Depends(require_super_admin)
):
    """Statistiques globales de la plateforme"""
    total_users = await db.users.count_documents({})
    total_events = await db.events.count_documents({})
    total_bookings = await db.bookings.count_documents({})
    
    # Statistiques par plan
    users_by_plan = {}
    async for user in db.users.find({}, {"_id": 0, "subscription_plan": 1}):
        plan = user.get("subscription_plan", "free")
        users_by_plan[plan] = users_by_plan.get(plan, 0) + 1
    
    return {
        "total_users": total_users,
        "total_events": total_events,
        "total_bookings": total_bookings,
        "users_by_plan": users_by_plan
    }
