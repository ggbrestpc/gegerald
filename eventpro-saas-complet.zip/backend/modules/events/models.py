# Modèles pour les événements, catégories, places et tarifs
from pydantic import BaseModel, Field, ConfigDict, HttpUrl
from typing import Optional, List
from datetime import datetime, timezone
import uuid


class Category(BaseModel):
    """Modèle pour une catégorie d'événement"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    name: str
    slug: str
    color: str = "#6366F1"  # Couleur personnalisable par le client
    icon: Optional[str] = None
    description: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class CategoryCreate(BaseModel):
    """Modèle pour créer une catégorie"""
    name: str
    slug: str
    color: str = "#6366F1"
    icon: Optional[str] = None
    description: Optional[str] = None


class PriceOption(BaseModel):
    """Modèle pour un tarif de place"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str  # ex: "Standard", "VIP", "Early Bird"
    price: float
    currency: str = "EUR"
    available_seats: int
    sold_seats: int = 0
    description: Optional[str] = None


class PriceOptionCreate(BaseModel):
    """Modèle pour créer un tarif"""
    name: str
    price: float
    currency: str = "EUR"
    available_seats: int
    description: Optional[str] = None


class Event(BaseModel):
    """Modèle pour un événement complet"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Propriétaire de l'événement
    title: str
    slug: str
    description: str
    category_id: str
    
    # Dates et lieu
    start_date: datetime
    end_date: datetime
    location: str
    address: str
    city: str
    postal_code: str
    country: str = "France"
    
    # Médias
    cover_image: Optional[str] = None  # URL image principale (WebP)
    gallery_images: List[str] = []  # URLs images additionnelles
    
    # Places et tarifs
    price_options: List[PriceOption] = []
    total_seats: int = 0
    
    # Personnalisation
    button_text: str = "Réserver ma place"
    button_color: str = "#6366F1"
    custom_css: Optional[str] = None
    
    # SEO
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    keywords: List[str] = []
    
    # Statut
    is_published: bool = False
    is_featured: bool = False
    
    # Données structurées pour SEO
    structured_data: dict = {}
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class EventCreate(BaseModel):
    """Modèle pour créer un événement"""
    title: str
    slug: str
    description: str
    category_id: str
    start_date: datetime
    end_date: datetime
    location: str
    address: str
    city: str
    postal_code: str
    country: str = "France"
    cover_image: Optional[str] = None
    price_options: List[PriceOptionCreate] = []
    button_text: str = "Réserver ma place"
    button_color: str = "#6366F1"
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    keywords: List[str] = []


class EventUpdate(BaseModel):
    """Modèle pour mettre à jour un événement"""
    title: Optional[str] = None
    description: Optional[str] = None
    category_id: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    location: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    postal_code: Optional[str] = None
    is_published: Optional[bool] = None
    button_text: Optional[str] = None
    button_color: Optional[str] = None
