# Routes pour la gestion des événements
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from typing import List
from ..auth.models import User, UserRole
from ..auth.routes import get_current_user
from .models import Event, EventCreate, EventUpdate, Category, CategoryCreate, PriceOption
from database import db
from datetime import datetime, timezone

router = APIRouter(prefix="/events", tags=["Events"])


@router.post("/categories", response_model=Category)
async def create_category(
    category_data: CategoryCreate,
    current_user: User = Depends(get_current_user)
):
    """Crée une nouvelle catégorie d'événement"""
    # Vérifier si le slug existe déjà pour cet utilisateur
    existing = await db.categories.find_one(
        {"user_id": current_user.id, "slug": category_data.slug},
        {"_id": 0}
    )
    if existing:
        raise HTTPException(status_code=400, detail="Ce slug de catégorie existe déjà")
    
    category = Category(
        user_id=current_user.id,
        **category_data.model_dump()
    )
    
    category_dict = category.model_dump()
    category_dict["created_at"] = category_dict["created_at"].isoformat()
    
    await db.categories.insert_one(category_dict)
    return category


@router.get("/categories", response_model=List[Category])
async def get_categories(
    current_user: User = Depends(get_current_user)
):
    """Récupère toutes les catégories de l'utilisateur"""
    categories = await db.categories.find(
        {"user_id": current_user.id},
        {"_id": 0}
    ).to_list(1000)
    return categories


@router.post("/", response_model=Event)
async def create_event(
    event_data: EventCreate,
    current_user: User = Depends(get_current_user)
):
    """Crée un nouvel événement"""
    # Vérifier les limites de l'abonnement
    user_events_count = await db.events.count_documents({"user_id": current_user.id})
    if user_events_count >= current_user.events_limit:
        raise HTTPException(
            status_code=403,
            detail=f"Limite d'événements atteinte ({current_user.events_limit}). Veuillez upgrader votre abonnement."
        )
    
    # Vérifier si la catégorie existe
    category = await db.categories.find_one(
        {"id": event_data.category_id, "user_id": current_user.id},
        {"_id": 0}
    )
    if not category:
        raise HTTPException(status_code=404, detail="Catégorie non trouvée")
    
    # Créer les options de prix
    price_options = [
        PriceOption(**opt.model_dump())
        for opt in event_data.price_options
    ]
    
    # Calculer le total des places
    total_seats = sum(opt.available_seats for opt in price_options)
    
    # Générer les données structurées pour SEO
    structured_data = {
        "@context": "https://schema.org",
        "@type": "Event",
        "name": event_data.title,
        "description": event_data.description,
        "startDate": event_data.start_date.isoformat(),
        "endDate": event_data.end_date.isoformat(),
        "location": {
            "@type": "Place",
            "name": event_data.location,
            "address": {
                "@type": "PostalAddress",
                "streetAddress": event_data.address,
                "addressLocality": event_data.city,
                "postalCode": event_data.postal_code,
                "addressCountry": event_data.country
            }
        }
    }
    
    event = Event(
        user_id=current_user.id,
        **event_data.model_dump(exclude={"price_options"}),
        price_options=price_options,
        total_seats=total_seats,
        structured_data=structured_data
    )
    
    event_dict = event.model_dump()
    event_dict["created_at"] = event_dict["created_at"].isoformat()
    event_dict["updated_at"] = event_dict["updated_at"].isoformat()
    event_dict["start_date"] = event_dict["start_date"].isoformat()
    event_dict["end_date"] = event_dict["end_date"].isoformat()
    
    await db.events.insert_one(event_dict)
    return event


@router.get("/", response_model=List[Event])
async def get_events(
    current_user: User = Depends(get_current_user)
):
    """Récupère tous les événements de l'utilisateur"""
    events = await db.events.find(
        {"user_id": current_user.id},
        {"_id": 0}
    ).to_list(1000)
    return events


@router.get("/{event_id}", response_model=Event)
async def get_event(
    event_id: str,
    current_user: User = Depends(get_current_user)
):
    """Récupère un événement spécifique"""
    event = await db.events.find_one(
        {"id": event_id, "user_id": current_user.id},
        {"_id": 0}
    )
    if not event:
        raise HTTPException(status_code=404, detail="Événement non trouvé")
    return event


@router.put("/{event_id}", response_model=Event)
async def update_event(
    event_id: str,
    event_data: EventUpdate,
    current_user: User = Depends(get_current_user)
):
    """Met à jour un événement"""
    # Vérifier que l'événement existe et appartient à l'utilisateur
    event = await db.events.find_one(
        {"id": event_id, "user_id": current_user.id},
        {"_id": 0}
    )
    if not event:
        raise HTTPException(status_code=404, detail="Événement non trouvé")
    
    # Préparer les données de mise à jour
    update_data = event_data.model_dump(exclude_unset=True)
    if update_data:
        update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
        
        # Convertir les dates en ISO string si présentes
        for date_field in ["start_date", "end_date"]:
            if date_field in update_data and update_data[date_field]:
                update_data[date_field] = update_data[date_field].isoformat()
        
        await db.events.update_one(
            {"id": event_id},
            {"$set": update_data}
        )
    
    # Récupérer l'événement mis à jour
    updated_event = await db.events.find_one({"id": event_id}, {"_id": 0})
    return updated_event


@router.delete("/{event_id}")
async def delete_event(
    event_id: str,
    current_user: User = Depends(get_current_user)
):
    """Supprime un événement"""
    result = await db.events.delete_one(
        {"id": event_id, "user_id": current_user.id}
    )
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Événement non trouvé")
    
    return {"message": "Événement supprimé avec succès"}


# Route publique pour voir un événement
@router.get("/public/{user_slug}/{event_slug}", response_model=Event)
async def get_public_event(
    user_slug: str,
    event_slug: str
):
    """Récupère un événement public (sans authentification)"""
    # Trouver l'utilisateur par slug (on pourrait ajouter un champ slug au modèle User)
    event = await db.events.find_one(
        {"slug": event_slug, "is_published": True},
        {"_id": 0}
    )
    
    if not event:
        raise HTTPException(status_code=404, detail="Événement non trouvé")
    
    return event
