# Modèles d'authentification et utilisateurs
from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import Optional, List
from datetime import datetime, timezone
import uuid


class UserRole:
    """Rôles utilisateurs disponibles"""
    SUPER_ADMIN = "super_admin"
    CLIENT = "client"


class Permission(BaseModel):
    """Modèle pour les permissions individuelles"""
    model_config = ConfigDict(extra="ignore")
    
    name: str  # ex: "manage_events", "manage_categories", "view_analytics"
    description: str
    enabled: bool = True


class User(BaseModel):
    """Modèle utilisateur complet"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    full_name: str
    role: str = UserRole.CLIENT
    permissions: List[str] = []  # Liste des permissions activées
    company_name: Optional[str] = None
    is_active: bool = True
    stripe_customer_id: Optional[str] = None
    subscription_plan: Optional[str] = None  # "starter", "professional", "enterprise"
    subscription_status: Optional[str] = None  # "active", "canceled", "past_due"
    sites_limit: int = 1
    events_limit: int = 20
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class UserCreate(BaseModel):
    """Modèle pour créer un utilisateur"""
    email: EmailStr
    password: str
    full_name: str
    company_name: Optional[str] = None


class UserLogin(BaseModel):
    """Modèle pour la connexion"""
    email: EmailStr
    password: str


class Token(BaseModel):
    """Modèle de réponse JWT"""
    access_token: str
    token_type: str = "bearer"
    user: User


class UserUpdate(BaseModel):
    """Modèle pour mettre à jour un utilisateur"""
    full_name: Optional[str] = None
    company_name: Optional[str] = None
    permissions: Optional[List[str]] = None
