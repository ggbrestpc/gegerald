# Routes d'authentification
from fastapi import APIRouter, HTTPException, Header
from typing import Optional
from .models import User, UserCreate, UserLogin, Token, UserRole
from .utils import get_password_hash, verify_password, create_access_token, decode_access_token
from database import db

router = APIRouter(prefix="/auth", tags=["Authentication"])


async def get_current_user(authorization: Optional[str] = Header(None)) -> User:
    """D\u00e9pendance pour r\u00e9cup\u00e9rer l'utilisateur actuel depuis le token JWT"""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token manquant")
    
    token = authorization.split(" ")[1]
    payload = decode_access_token(token)
    
    if not payload:
        raise HTTPException(status_code=401, detail="Token invalide")
    
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Token invalide")
    
    # R\u00e9cup\u00e9rer l'utilisateur depuis la DB
    user_doc = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Utilisateur non trouv\u00e9")
    
    return User(**user_doc)


@router.post("/register", response_model=Token)
async def register(user_data: UserCreate):
    """Inscription d'un nouvel utilisateur"""
    # V\u00e9rifier si l'email existe d\u00e9j\u00e0
    existing_user = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email d\u00e9j\u00e0 utilis\u00e9")
    
    # Cr\u00e9er le nouvel utilisateur
    hashed_password = get_password_hash(user_data.password)
    
    new_user = User(
        email=user_data.email,
        full_name=user_data.full_name,
        company_name=user_data.company_name,
        role=UserRole.CLIENT
    )
    
    user_dict = new_user.model_dump()
    user_dict["hashed_password"] = hashed_password
    user_dict["created_at"] = user_dict["created_at"].isoformat()
    user_dict["updated_at"] = user_dict["updated_at"].isoformat()
    
    await db.users.insert_one(user_dict)
    
    # Cr\u00e9er le token JWT
    access_token = create_access_token(data={"sub": new_user.id, "role": new_user.role})
    
    return Token(access_token=access_token, user=new_user)


@router.post("/login", response_model=Token)
async def login(credentials: UserLogin):
    """Connexion utilisateur"""
    # R\u00e9cup\u00e9rer l'utilisateur
    user_doc = await db.users.find_one({"email": credentials.email})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    
    # V\u00e9rifier le mot de passe
    if not verify_password(credentials.password, user_doc["hashed_password"]):
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    
    # V\u00e9rifier si le compte est actif
    if not user_doc.get("is_active", True):
        raise HTTPException(status_code=403, detail="Compte d\u00e9sactiv\u00e9")
    
    # Cr\u00e9er l'objet User (sans le mot de passe)
    user_doc.pop("_id", None)
    user_doc.pop("hashed_password", None)
    user = User(**user_doc)
    
    # Cr\u00e9er le token JWT
    access_token = create_access_token(data={"sub": user.id, "role": user.role})
    
    return Token(access_token=access_token, user=user)


@router.get("/me", response_model=User)
async def get_me(authorization: str = Header(None, alias="Authorization")):
    """R\u00e9cup\u00e8re les informations de l'utilisateur connect\u00e9"""
    return await get_current_user(authorization)
