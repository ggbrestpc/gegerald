# Module d'authentification
# Gestion JWT, permissions, rôles (super_admin, client)