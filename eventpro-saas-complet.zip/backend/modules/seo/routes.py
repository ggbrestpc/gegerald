# Générateur SEO automatique
from fastapi import APIRouter, HTTPException
import aiohttp
from typing import List
from database import db

router = APIRouter(prefix="/seo", tags=["SEO"])


@router.get("/cities")
async def fetch_french_cities():
    """Récupère les villes françaises depuis l'API gouv.fr"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://geo.api.gouv.fr/communes?fields=nom,code,codesPostaux,population&format=json&geometry=centre"
            ) as response:
                if response.status == 200:
                    cities = await response.json()
                    # Filtrer les villes avec plus de 50k habitants
                    major_cities = [
                        city for city in cities 
                        if city.get('population', 0) > 50000
                    ]
                    return {"cities": major_cities[:100]}  # Top 100
                else:
                    raise HTTPException(status_code=500, detail="Erreur API gouv.fr")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate-city-pages")
async def generate_city_pages():
    """Génère des pages SEO pour les principales villes"""
    # Récupérer les villes
    cities_data = await fetch_french_cities()
    cities = cities_data["cities"]
    
    # Récupérer les catégories
    categories = await db.categories.find({}, {"_id": 0}).to_list(1000)
    
    seo_pages = []
    
    for city in cities[:20]:  # Top 20 villes
        for category in categories[:5]:  # Top 5 catégories
            page = {
                "city": city["nom"],
                "category": category["name"],
                "slug": f"{category['slug']}-{city['nom'].lower().replace(' ', '-')}",
                "meta_title": f"{category['name']} à {city['nom']} - Événements et Billetterie",
                "meta_description": f"Découvrez tous les événements {category['name']} à {city['nom']}. Réservez vos billets en ligne facilement.",
                "h1": f"Événements {category['name']} à {city['nom']}",
                "content": f"Trouvez et réservez les meilleurs événements {category['name']} à {city['nom']}. Billetterie en ligne sécurisée."
            }
            seo_pages.append(page)
    
    # Sauvegarder dans la DB
    if seo_pages:
        await db.seo_pages.insert_many(seo_pages)
    
    return {"message": f"{len(seo_pages)} pages SEO générées", "pages": len(seo_pages)}


@router.get("/sitemap")
async def generate_sitemap():
    """Génère un sitemap XML"""
    # Récupérer tous les événements publiés
    events = await db.events.find({"is_published": True}, {"_id": 0, "slug": 1, "updated_at": 1}).to_list(10000)
    
    # Récupérer les pages SEO
    seo_pages = await db.seo_pages.find({}, {"_id": 0, "slug": 1}).to_list(10000)
    
    sitemap_entries = []
    
    # Ajouter les événements
    for event in events:
        sitemap_entries.append({
            "url": f"/events/{event['slug']}",
            "lastmod": event.get('updated_at', ''),
            "priority": "0.8"
        })
    
    # Ajouter les pages SEO
    for page in seo_pages:
        sitemap_entries.append({
            "url": f"/seo/{page['slug']}",
            "priority": "0.6"
        })
    
    return {"entries": sitemap_entries, "total": len(sitemap_entries)}
