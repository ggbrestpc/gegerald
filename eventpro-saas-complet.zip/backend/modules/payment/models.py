# Modèles pour les paiements et abonnements
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime, timezone
import uuid


class SubscriptionPlan:
    """Plans d'abonnement disponibles"""
    STARTER = {
        "name": "starter",
        "price": 39,
        "sites_limit": 1,
        "events_limit": 20,
        "stripe_price_id": "price_starter"  # À remplacer par les vrais IDs Stripe
    }
    PROFESSIONAL = {
        "name": "professional",
        "price": 99,
        "sites_limit": 3,
        "events_limit": 100,
        "stripe_price_id": "price_professional"
    }
    ENTERPRISE = {
        "name": "enterprise",
        "price": 249,
        "sites_limit": 999999,  # Illimité
        "events_limit": 999999,  # Illimité
        "stripe_price_id": "price_enterprise"
    }


class Booking(BaseModel):
    """Modèle pour une réservation/achat de billet"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    event_id: str
    price_option_id: str
    
    # Informations client
    customer_email: str
    customer_name: str
    customer_phone: Optional[str] = None
    
    # Informations de paiement
    quantity: int = 1
    total_amount: float
    currency: str = "EUR"
    stripe_payment_intent_id: Optional[str] = None
    stripe_charge_id: Optional[str] = None
    payment_status: str = "pending"  # pending, succeeded, failed, refunded
    
    # QR Code
    qr_code: str = Field(default_factory=lambda: str(uuid.uuid4()))  # Code unique
    qr_code_image: Optional[str] = None  # URL de l'image QR
    
    # Statut
    is_validated: bool = False
    validated_at: Optional[datetime] = None
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class BookingCreate(BaseModel):
    """Modèle pour créer une réservation"""
    event_id: str
    price_option_id: str
    customer_email: str
    customer_name: str
    customer_phone: Optional[str] = None
    quantity: int = 1


class CreateCheckoutSession(BaseModel):
    """Modèle pour créer une session de paiement Stripe"""
    plan: str  # "starter", "professional", "enterprise"


class WebhookStripeConfig(BaseModel):
    """Configuration webhook Stripe personnalisé par client"""
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    webhook_url: str
    is_active: bool = True
    events: list = ["payment_intent.succeeded", "charge.refunded"]
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
