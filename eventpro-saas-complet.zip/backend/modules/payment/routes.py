# Routes pour les paiements Stripe
from fastapi import APIRouter, HTTPException, Depends, Request
from motor.motor_asyncio import AsyncIOMotorDatabase
import stripe
import json
import os
from typing import List
from ..auth.models import User
from database import db
from ..auth.routes import get_current_user
from .models import Booking, BookingCreate, SubscriptionPlan, CreateCheckoutSession
from datetime import datetime, timezone
import qrcode
from io import BytesIO
import base64

router = APIRouter(prefix="/payment", tags=["Payment"])

# Charger la config Stripe depuis config.json
config_path = os.path.join(os.path.dirname(__file__), "../../config.json")
try:
    with open(config_path, "r") as f:
        config = json.load(f)
        stripe.api_key = config.get("stripe", {}).get("secret_key", "")
except:
    stripe.api_key = ""  # Sera configuré par l'utilisateur


@router.post("/create-checkout-session")
async def create_checkout_session(
    session_data: CreateCheckoutSession,
    current_user: User = Depends(get_current_user)
):
    """Crée une session Stripe Checkout pour un abonnement"""
    # Sélectionner le plan
    plan_map = {
        "starter": SubscriptionPlan.STARTER,
        "professional": SubscriptionPlan.PROFESSIONAL,
        "enterprise": SubscriptionPlan.ENTERPRISE
    }
    
    plan = plan_map.get(session_data.plan)
    if not plan:
        raise HTTPException(status_code=400, detail="Plan invalide")
    
    try:
        # Créer ou récupérer le client Stripe
        if current_user.stripe_customer_id:
            customer_id = current_user.stripe_customer_id
        else:
            customer = stripe.Customer.create(
                email=current_user.email,
                name=current_user.full_name,
                metadata={"user_id": current_user.id}
            )
            customer_id = customer.id
            
            # Mettre à jour l'utilisateur avec l'ID client Stripe
            await db.users.update_one(
                {"id": current_user.id},
                {"$set": {"stripe_customer_id": customer_id}}
            )
        
        # Créer la session Checkout
        checkout_session = stripe.checkout.Session.create(
            customer=customer_id,
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": "eur",
                    "product_data": {
                        "name": f"Plan {plan['name'].capitalize()}",
                        "description": f"{plan['sites_limit']} sites, {plan['events_limit']} événements"
                    },
                    "unit_amount": plan["price"] * 100,  # En centimes
                    "recurring": {"interval": "month"}
                },
                "quantity": 1
            }],
            mode="subscription",
            success_url=f"{os.environ.get('FRONTEND_URL', 'http://localhost:3000')}/dashboard?subscription=success",
            cancel_url=f"{os.environ.get('FRONTEND_URL', 'http://localhost:3000')}/pricing?subscription=canceled",
            metadata={
                "user_id": current_user.id,
                "plan": plan["name"]
            }
        )
        
        return {"checkout_url": checkout_session.url, "session_id": checkout_session.id}
    
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/create-booking", response_model=Booking)
async def create_booking(
    booking_data: BookingCreate
):
    """Crée une réservation pour un événement (sans authentification)"""
    # Récupérer l'événement
    event = await db.events.find_one({"id": booking_data.event_id}, {"_id": 0})
    if not event:
        raise HTTPException(status_code=404, detail="Événement non trouvé")
    
    # Trouver l'option de prix
    price_option = None
    for opt in event.get("price_options", []):
        if opt["id"] == booking_data.price_option_id:
            price_option = opt
            break
    
    if not price_option:
        raise HTTPException(status_code=404, detail="Option de prix non trouvée")
    
    # Vérifier la disponibilité
    if price_option["sold_seats"] + booking_data.quantity > price_option["available_seats"]:
        raise HTTPException(status_code=400, detail="Plus assez de places disponibles")
    
    # Calculer le montant total
    total_amount = price_option["price"] * booking_data.quantity
    
    # Créer la réservation
    booking = Booking(
        **booking_data.model_dump(),
        total_amount=total_amount,
        currency=price_option.get("currency", "EUR")
    )
    
    # Générer le QR code
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(booking.qr_code)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")
    
    # Convertir en base64
    buffered = BytesIO()
    qr_img.save(buffered, format="PNG")
    qr_base64 = base64.b64encode(buffered.getvalue()).decode()
    booking.qr_code_image = f"data:image/png;base64,{qr_base64}"
    
    # Sauvegarder la réservation
    booking_dict = booking.model_dump()
    booking_dict["created_at"] = booking_dict["created_at"].isoformat()
    
    await db.bookings.insert_one(booking_dict)
    
    # TODO: Créer le Payment Intent Stripe et envoyer l'email avec QR code
    
    return booking


@router.get("/bookings", response_model=List[Booking])
async def get_bookings(
    event_id: str = None,
    current_user: User = Depends(get_current_user)
):
    """Récupère les réservations (filtrées par événement si spécifié)"""
    # Vérifier que l'utilisateur a accès aux événements
    query = {}
    if event_id:
        # Vérifier que l'événement appartient à l'utilisateur
        event = await db.events.find_one(
            {"id": event_id, "user_id": current_user.id},
            {"_id": 0}
        )
        if not event:
            raise HTTPException(status_code=404, detail="Événement non trouvé")
        query["event_id"] = event_id
    else:
        # Récupérer tous les événements de l'utilisateur
        user_events = await db.events.find(
            {"user_id": current_user.id},
            {"_id": 0, "id": 1}
        ).to_list(1000)
        event_ids = [e["id"] for e in user_events]
        query["event_id"] = {"$in": event_ids}
    
    bookings = await db.bookings.find(query, {"_id": 0}).to_list(10000)
    return bookings


@router.post("/validate-qr/{qr_code}")
async def validate_qr_code(
    qr_code: str,
    current_user: User = Depends(get_current_user)
):
    """Valide un QR code pour l'entrée à un événement"""
    # Récupérer la réservation
    booking = await db.bookings.find_one({"qr_code": qr_code}, {"_id": 0})
    if not booking:
        raise HTTPException(status_code=404, detail="QR code invalide")
    
    # Vérifier que l'événement appartient à l'utilisateur
    event = await db.events.find_one(
        {"id": booking["event_id"], "user_id": current_user.id},
        {"_id": 0}
    )
    if not event:
        raise HTTPException(status_code=403, detail="Vous n'avez pas accès à cet événement")
    
    # Vérifier si déjà validé
    if booking.get("is_validated"):
        return {
            "status": "already_validated",
            "message": "Ce billet a déjà été utilisé",
            "validated_at": booking.get("validated_at")
        }
    
    # Marquer comme validé
    await db.bookings.update_one(
        {"qr_code": qr_code},
        {
            "$set": {
                "is_validated": True,
                "validated_at": datetime.now(timezone.utc).isoformat()
            }
        }
    )
    
    return {
        "status": "validated",
        "message": "Billet validé avec succès",
        "booking": booking
    }


@router.post("/webhook")
async def stripe_webhook(request: Request):
    """Webhook pour recevoir les événements Stripe"""
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")
    
    # Charger le secret webhook depuis config.json
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
            webhook_secret = config.get("stripe", {}).get("webhook_secret", "")
    except:
        webhook_secret = ""
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    # Gérer les différents types d'événements
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = session.get("metadata", {}).get("user_id")
        plan = session.get("metadata", {}).get("plan")
        
        if user_id and plan:
            # Mettre à jour l'abonnement de l'utilisateur
            plan_config = getattr(SubscriptionPlan, plan.upper(), None)
            if plan_config:
                await db.users.update_one(
                    {"id": user_id},
                    {
                        "$set": {
                            "subscription_plan": plan,
                            "subscription_status": "active",
                            "sites_limit": plan_config["sites_limit"],
                            "events_limit": plan_config["events_limit"]
                        }
                    }
                )
    
    return {"status": "success"}
