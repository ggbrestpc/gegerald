# Utilitaire pour envoyer des emails via SMTP
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import json
import os
from typing import Optional

# Charger la config SMTP depuis config.json
config_path = os.path.join(os.path.dirname(__file__), "../../config.json")
try:
    with open(config_path, "r") as f:
        config = json.load(f)
        SMTP_CONFIG = config.get("smtp", {})
except:
    SMTP_CONFIG = {}


async def send_email(
    to_email: str,
    subject: str,
    html_content: str,
    attachments: Optional[list] = None
):
    """Envoie un email via SMTP"""
    message = MIMEMultipart("alternative")
    message["From"] = SMTP_CONFIG.get("from_email", "noreply@eventpro.com")
    message["To"] = to_email
    message["Subject"] = subject
    
    # Ajouter le contenu HTML
    html_part = MIMEText(html_content, "html")
    message.attach(html_part)
    
    # Ajouter les pièces jointes si présentes
    if attachments:
        for attachment in attachments:
            message.attach(attachment)
    
    try:
        await aiosmtplib.send(
            message,
            hostname=SMTP_CONFIG.get("host", "localhost"),
            port=SMTP_CONFIG.get("port", 587),
            username=SMTP_CONFIG.get("username", ""),
            password=SMTP_CONFIG.get("password", ""),
            start_tls=True
        )
        return True
    except Exception as e:
        print(f"Erreur lors de l'envoi de l'email: {str(e)}")
        return False


def generate_ticket_email(booking: dict, event: dict) -> str:
    """Génère le HTML d'un email de billet avec QR code"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{
                font-family: 'Arial', sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                margin: 0;
                padding: 40px 20px;
            }}
            .container {{
                max-width: 600px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                overflow: hidden;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }}
            .header {{
                background: #6366F1;
                color: white;
                padding: 40px 30px;
                text-align: center;
            }}
            .header h1 {{
                margin: 0;
                font-size: 32px;
                font-weight: 800;
            }}
            .content {{
                padding: 40px 30px;
            }}
            .ticket-info {{
                background: #F8FAFC;
                border-radius: 12px;
                padding: 25px;
                margin: 20px 0;
            }}
            .ticket-info h2 {{
                color: #0F172A;
                margin: 0 0 15px 0;
                font-size: 24px;
            }}
            .ticket-info p {{
                color: #475569;
                margin: 8px 0;
                font-size: 16px;
            }}
            .qr-container {{
                text-align: center;
                margin: 30px 0;
                padding: 30px;
                background: white;
                border: 3px dashed #6366F1;
                border-radius: 12px;
            }}
            .qr-container img {{
                max-width: 250px;
                height: auto;
            }}
            .qr-code-text {{
                font-family: monospace;
                font-size: 14px;
                color: #64748B;
                margin-top: 15px;
            }}
            .footer {{
                background: #F1F5F9;
                padding: 30px;
                text-align: center;
                color: #64748B;
            }}
            .button {{
                display: inline-block;
                background: #6366F1;
                color: white;
                padding: 15px 40px;
                border-radius: 10px;
                text-decoration: none;
                font-weight: bold;
                margin: 20px 0;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>✨ Votre Billet</h1>
            </div>
            <div class="content">
                <p>Bonjour {booking.get('customer_name', '')},</p>
                <p>Merci pour votre réservation ! Voici votre billet pour :</p>
                
                <div class="ticket-info">
                    <h2>{event.get('title', '')}</h2>
                    <p><strong>📅 Date :</strong> {event.get('start_date', '')}</p>
                    <p><strong>📍 Lieu :</strong> {event.get('location', '')}</p>
                    <p><strong>🎫 Places :</strong> {booking.get('quantity', 1)}</p>
                </div>
                
                <div class="qr-container">
                    <p style="font-size: 18px; font-weight: bold; color: #0F172A; margin-bottom: 15px;">
                        Votre QR Code d'entrée
                    </p>
                    <img src="{booking.get('qr_code_image', '')}" alt="QR Code" />
                    <p class="qr-code-text">Code: {booking.get('qr_code', '')}</p>
                    <p style="color: #64748B; font-size: 14px; margin-top: 20px;">
                        Présentez ce QR code à l'entrée de l'événement
                    </p>
                </div>
            </div>
            <div class="footer">
                <p>À très bientôt !</p>
                <p style="font-size: 12px; margin-top: 20px;">
                    Cet email contient votre billet. Ne le transférez pas.
                </p>
            </div>
        </div>
    </body>
    </html>
    """
