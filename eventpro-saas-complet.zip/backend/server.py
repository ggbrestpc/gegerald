from fastapi import FastAPI, APIRouter
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import logging
from pathlib import Path

# Importer les modules de l'application
from modules.auth import routes as auth_routes
from modules.events import routes as events_routes
from modules.payment import routes as payment_routes
from modules.media import routes as media_routes
from modules.super_admin import routes as super_admin_routes
from modules.seo import routes as seo_routes
from modules.themes import routes as themes_routes


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Create the main app without a prefix
app = FastAPI(title="EventPro SaaS API", version="1.0.0")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Route principale
@api_router.get("/")
async def root():
    return {
        "message": "Bienvenue sur EventPro SaaS API",
        "version": "1.0.0",
        "status": "active"
    }


# Inclure tous les routers des modules
api_router.include_router(auth_routes.router)
api_router.include_router(events_routes.router)
api_router.include_router(payment_routes.router)
api_router.include_router(media_routes.router)
api_router.include_router(super_admin_routes.router)
api_router.include_router(seo_routes.router)
api_router.include_router(themes_routes.router)

# Include the main api router in the app
app.include_router(api_router)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    from database import client
    client.close()
