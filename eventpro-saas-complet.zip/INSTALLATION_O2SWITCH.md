# Guide d'Installation EventPro SaaS sur o2switch

## 📋 Prérequis

- Compte o2switch actif
- Accès cPanel
- Node.js 18+ (disponible via cPanel)
- Python 3.11+ (disponible via cPanel)
- MongoDB (vous devrez utiliser MongoDB Atlas - gratuit)

## ⚠️ Note Importante sur o2switch

o2switch est optimisé pour PHP/MySQL. Pour cette stack Python/FastAPI/React/MongoDB, je recommande :

### Option 1 : Hébergement Cloud Recommandé
**Pour une performance optimale, utilisez plutôt :**
- **Vercel** (frontend React) - GRATUIT
- **Railway** ou **Render** (backend FastAPI) - GRATUIT pour commencer
- **MongoDB Atlas** (base de données) - GRATUIT jusqu'à 512MB

### Option 2 : Installation sur o2switch (Avancé)

Si vous souhaitez absolument utiliser o2switch, voici la procédure :

## 🚀 Installation sur o2switch

### Étape 1 : Préparation MongoDB Atlas

1. Créez un compte gratuit sur [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Créez un cluster gratuit
3. Créez un utilisateur de base de données
4. Whitelist votre IP
5. Copiez la connection string MongoDB

### Étape 2 : Upload des Fichiers

1. Connectez-vous à cPanel
2. Ouvrez le Gestionnaire de fichiers
3. Créez un dossier `eventpro` dans votre home directory
4. Uploadez le contenu du ZIP dans ce dossier

### Étape 3 : Configuration Backend

```bash
# Via Terminal SSH de cPanel
cd ~/eventpro/backend

# Créer un environnement virtuel Python
python3.11 -m venv venv
source venv/bin/activate

# Installer les dépendances
pip install -r requirements.txt

# Configurer les variables d'environnement
nano .env
```

Modifiez `.env` :
```
MONGO_URL="votre_connection_string_mongodb_atlas"
DB_NAME="eventpro"
CORS_ORIGINS="*"
JWT_SECRET_KEY="votre_secret_key_tres_securise"
```

Modifiez `config.json` avec vos clés Stripe :
```json
{
  "stripe": {
    "secret_key": "sk_test_...",
    "publishable_key": "pk_test_...",
    "webhook_secret": "whsec_..."
  },
  "smtp": {
    "host": "smtp.votredomaine.com",
    "port": 587,
    "username": "noreply@votredomaine.com",
    "password": "votre_mot_de_passe",
    "from_email": "noreply@votredomaine.com"
  }
}
```

### Étape 4 : Configuration Frontend

```bash
cd ~/eventpro/frontend

# Installer Node.js via cPanel Node.js Selector
# Puis installer les dépendances
npm install

# Build de production
npm run build
```

Modifiez `frontend/.env` :
```
REACT_APP_BACKEND_URL=https://votredomaine.com/api
```

### Étape 5 : Configuration Apache

Créez un fichier `.htaccess` dans votre `public_html` :

```apache
# Backend API
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^api/(.*)$ http://localhost:8001/api/$1 [P,L]
</IfModule>

# Frontend React
RewriteEngine On
RewriteBase /
RewriteRule ^index\.html$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]
```

### Étape 6 : Démarrage de l'Application

**Backend (via screen ou tmux) :**
```bash
cd ~/eventpro/backend
source venv/bin/activate
uvicorn server:app --host 0.0.0.0 --port 8001
```

**Frontend :**
Copiez le contenu de `frontend/build` vers `public_html`

```bash
cp -r ~/eventpro/frontend/build/* ~/public_html/
```

## 📊 Solution Recommandée (Plus Simple)

### Déploiement Cloud Gratuit

#### Frontend sur Vercel (Gratuit)
```bash
# Dans le dossier frontend
npm install -g vercel
vercel login
vercel --prod
```

#### Backend sur Railway (Gratuit)
1. Créez un compte sur [Railway.app](https://railway.app)
2. Connectez votre repo GitHub
3. Déployez le dossier `backend`
4. Railway créera automatiquement l'URL

#### Configuration
- Frontend `.env` : `REACT_APP_BACKEND_URL=https://votre-backend.railway.app`
- Backend géré par Railway
- MongoDB Atlas (gratuit)

**Avantages :**
- ✅ Déploiement en 5 minutes
- ✅ HTTPS automatique
- ✅ Mise à jour automatique (CI/CD)
- ✅ Pas de gestion serveur
- ✅ Performance optimale
- ✅ Gratuit pour commencer

## 🔧 Configuration des Services

### Stripe
1. Créez un compte sur [Stripe](https://stripe.com)
2. Mode test : utilisez les clés de test
3. Production : activez votre compte et utilisez les clés live
4. Configurez les webhooks pour `/api/payment/webhook`

### SMTP (Emails)
- **Option 1** : SMTP o2switch (depuis cPanel)
- **Option 2** : Brevo (ex-Sendinblue) - 300 emails/jour gratuits
- **Option 3** : Resend - 3000 emails/mois gratuits

## 📱 Fonctionnalités Activées

✅ Landing page marketing
✅ Authentification (JWT)
✅ Dashboard Client
✅ Gestion événements & catégories
✅ Billetterie Stripe
✅ QR Codes sécurisés
✅ Upload images (WebP automatique)
✅ Super Admin Dashboard
✅ Marketplace thèmes
✅ Générateur SEO (API gouv.fr)
✅ Scanner QR PWA
✅ 3 plans d'abonnement

## 🆘 Support

### Problèmes Courants

**Backend ne démarre pas :**
- Vérifiez que MongoDB Atlas est accessible
- Vérifiez les logs : `tail -f ~/eventpro/backend/logs/error.log`

**Frontend erreur CORS :**
- Vérifiez `CORS_ORIGINS` dans backend `.env`
- Ajoutez votre domaine

**Stripe ne fonctionne pas :**
- Vérifiez les clés dans `config.json`
- Testez avec les clés de test d'abord

## 📞 Contact

Pour toute question sur le déploiement, consultez :
- Documentation o2switch : https://faq.o2switch.fr/
- Documentation Vercel : https://vercel.com/docs
- Documentation Railway : https://docs.railway.app/

---

**Conseil :** Pour un SaaS professionnel, utilisez la solution cloud (Vercel + Railway + MongoDB Atlas) plutôt que o2switch. C'est plus simple, plus performant et évolutif !
