# EventPro SaaS - Plateforme de Gestion d'Événements

## 🎯 Description

EventPro est une plateforme SaaS complète pour la gestion d'événements avec billetterie intégrée, QR codes sécurisés, marketplace de thèmes et bien plus encore.

## ✨ Fonctionnalités

### Pour les Organisateurs (Clients)
- ✅ **Gestion d'événements** : Création, modification, publication
- ✅ **Catégories personnalisables** : Couleurs et organisation
- ✅ **Billetterie Stripe** : Paiements sécurisés en ligne
- ✅ **QR Codes uniques** : Génération automatique pour chaque billet
- ✅ **Scanner PWA** : Validation d'entrée via smartphone
- ✅ **Upload d'images** : Conversion automatique en WebP
- ✅ **Personnalisation** : Boutons, couleurs, thèmes
- ✅ **Pages publiques** : Une page dédiée par événement
- ✅ **Webhooks** : Intégration avec vos outils

### Pour les Super Admins
- ✅ **Gestion utilisateurs** : Activation/désactivation
- ✅ **Permissions** : Configuration par cases à cocher
- ✅ **Marketplace thèmes** : Création et vente de thèmes
- ✅ **Analytics** : Statistiques globales de la plateforme
- ✅ **SEO automatique** : Génération de pages pour les villes

### Plans d'Abonnement
- **Starter** : 39€/mois - 1 site, 20 événements
- **Professional** : 99€/mois - 3 sites, 100 événements
- **Enterprise** : 249€/mois - Illimité

## 🏗️ Architecture Technique

### Backend (FastAPI + Python)
```
backend/
├── server.py                 # Point d'entrée FastAPI
├── database.py              # Connexion MongoDB
├── config.json              # Configuration Stripe/SMTP
├── requirements.txt         # Dépendances Python
└── modules/
    ├── auth/               # Authentification JWT
    ├── events/             # Gestion événements
    ├── payment/            # Stripe & QR codes
    ├── media/              # Upload & WebP
    ├── super_admin/        # Dashboard admin
    ├── seo/                # Générateur SEO
    ├── themes/             # Marketplace
    └── email/              # Envoi emails
```

### Frontend (React + Tailwind)
```
frontend/
├── src/
│   ├── pages/
│   │   ├── LandingPage.js          # Page d'accueil
│   │   ├── LoginPage.js            # Connexion
│   │   ├── RegisterPage.js         # Inscription
│   │   ├── PublicEventPage.js      # Page événement publique
│   │   ├── QRScannerPage.js        # Scanner PWA
│   │   └── dashboard/
│   │       ├── DashboardPage.js    # Dashboard principal
│   │       ├── EventsTab.js        # Onglet événements
│   │       ├── CategoriesTab.js    # Onglet catégories
│   │       └── SettingsTab.js      # Paramètres
│   ├── contexts/
│   │   └── AuthContext.js          # Gestion auth
│   ├── utils/
│   │   └── api.js                  # Client API
│   └── components/ui/              # Composants Shadcn
└── package.json
```

### Base de Données (MongoDB)
Collections :
- `users` : Utilisateurs et abonnements
- `events` : Événements
- `categories` : Catégories d'événements
- `bookings` : Réservations et billets
- `themes` : Marketplace de thèmes
- `seo_pages` : Pages SEO générées

## 🚀 Installation

### Méthode 1 : Cloud (Recommandé)

**Frontend (Vercel) :**
```bash
cd frontend
npm install
vercel --prod
```

**Backend (Railway) :**
1. Créez un compte sur Railway.app
2. Connectez votre repo GitHub
3. Déployez automatiquement

**Base de données (MongoDB Atlas) :**
1. Créez un cluster gratuit
2. Copiez la connection string
3. Configurez dans Railway

### Méthode 2 : Local

**Backend :**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Configurer .env
cp .env.example .env
nano .env

# Lancer
uvicorn server:app --reload
```

**Frontend :**
```bash
cd frontend
npm install
npm start
```

### Méthode 3 : o2switch
Consultez `INSTALLATION_O2SWITCH.md`

## ⚙️ Configuration

### 1. MongoDB
Fichier `backend/.env` :
```
MONGO_URL="mongodb://localhost:27017"
# Ou MongoDB Atlas:
MONGO_URL="mongodb+srv://user:pass@cluster.mongodb.net"
DB_NAME="eventpro"
```

### 2. Stripe
Fichier `backend/config.json` :
```json
{
  "stripe": {
    "secret_key": "sk_test_...",
    "publishable_key": "pk_test_...",
    "webhook_secret": "whsec_..."
  }
}
```

### 3. SMTP (Emails)
```json
{
  "smtp": {
    "host": "smtp.example.com",
    "port": 587,
    "username": "noreply@votredomaine.com",
    "password": "votre_password",
    "from_email": "noreply@votredomaine.com"
  }
}
```

### 4. Frontend
Fichier `frontend/.env` :
```
REACT_APP_BACKEND_URL=http://localhost:8001
# Production:
REACT_APP_BACKEND_URL=https://votre-api.com
```

## 📖 Utilisation

### Créer un Super Admin
```bash
# Via MongoDB shell ou Compass
db.users.updateOne(
  { "email": "admin@eventpro.com" },
  { $set: { "role": "super_admin" } }
)
```

### Endpoints API Principaux

**Authentification :**
- `POST /api/auth/register` - Inscription
- `POST /api/auth/login` - Connexion
- `GET /api/auth/me` - Profil utilisateur

**Événements :**
- `GET /api/events/` - Liste événements
- `POST /api/events/` - Créer événement
- `GET /api/events/{id}` - Détails événement
- `PUT /api/events/{id}` - Modifier
- `DELETE /api/events/{id}` - Supprimer

**Catégories :**
- `GET /api/events/categories` - Liste catégories
- `POST /api/events/categories` - Créer catégorie

**Paiement :**
- `POST /api/payment/create-checkout-session` - Session Stripe
- `POST /api/payment/create-booking` - Créer réservation
- `POST /api/payment/validate-qr/{code}` - Valider QR code

**Thèmes :**
- `GET /api/themes/` - Liste thèmes
- `POST /api/themes/purchase/{id}` - Acheter thème
- `GET /api/themes/my-themes` - Mes thèmes

**SEO :**
- `GET /api/seo/cities` - Villes françaises (API gouv.fr)
- `POST /api/seo/generate-city-pages` - Générer pages SEO
- `GET /api/seo/sitemap` - Sitemap XML

## 🎨 Design System

**Couleurs :**
- Primary : `#6366F1` (Electric Violet)
- Secondary : `#F43F5E` (Dynamic Coral)
- Accent : `#84CC16` (Lime Punch)

**Style :** Neo-Pop / Soft Brutalism
- Hard shadows (`3px 3px 0px 0px #0F172A`)
- Borders épaisses (`2px solid`)
- Couleurs vibrantes
- Animations micro-interactions

**Typographie :**
- Titres : Outfit (Google Fonts)
- Body : Plus Jakarta Sans (Google Fonts)

## 🔒 Sécurité

- ✅ JWT avec expiration (7 jours)
- ✅ Mots de passe hashés (bcrypt)
- ✅ CORS configuré
- ✅ Variables d'environnement
- ✅ QR codes uniques et vérifiables
- ✅ Stripe webhook signature validation

## 📦 Modules & Structure

Chaque module backend est dans un dossier séparé avec :
- `__init__.py` : Package init
- `models.py` : Modèles Pydantic
- `routes.py` : Endpoints FastAPI
- `utils.py` : Fonctions utilitaires (si nécessaire)

**Code commenté en français** dans tous les fichiers.

## 🐛 Dépannage

**Erreur MongoDB :**
```bash
# Vérifier la connexion
python -c "from pymongo import MongoClient; print(MongoClient('mongodb://localhost:27017').server_info())"
```

**Erreur CORS :**
- Vérifiez `CORS_ORIGINS` dans `backend/.env`
- Ajoutez votre domaine frontend

**Frontend ne se connecte pas :**
- Vérifiez `REACT_APP_BACKEND_URL` dans `frontend/.env`
- Vérifiez que le backend est démarré

**Stripe webhook échoue :**
- Utilisez Stripe CLI pour tester localement
- Configurez l'URL webhook dans le dashboard Stripe

## 📊 Performance

- ✅ Images WebP automatiques (réduction 30-80%)
- ✅ MongoDB indexé sur champs critiques
- ✅ React lazy loading
- ✅ API pagination
- ✅ CDN ready (images uploadées)

## 🚀 Roadmap

- [ ] Apple Wallet & Google Pay passes
- [ ] Analytics temps réel
- [ ] Export données (CSV, PDF)
- [ ] Multi-langue (i18n)
- [ ] Application mobile (React Native)
- [ ] Intégrations (Zoom, Google Meet)
- [ ] Chat support client

## 📄 Licence

Propriétaire - Tous droits réservés

## 👨‍💻 Développement

**Stack :**
- Backend : FastAPI 0.110+, Python 3.11+
- Frontend : React 19, Tailwind CSS 3.4
- Database : MongoDB 4.5+
- Paiements : Stripe
- Emails : SMTP (configurable)

**Développé avec :** ❤️ et beaucoup de ☕

---

Pour toute question : support@eventpro.com
