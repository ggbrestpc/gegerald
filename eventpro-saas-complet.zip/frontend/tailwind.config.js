const colors = require('tailwindcss/colors')

module.exports = {
  darkMode: ['class'],
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#6366F1',
          foreground: '#FFFFFF',
        },
        secondary: {
          DEFAULT: '#F43F5E',
          foreground: '#FFFFFF',
        },
        accent: {
          DEFAULT: '#84CC16',
          foreground: '#000000',
        },
        background: '#FFFFFF',
        foreground: '#0F172A',
        card: {
          DEFAULT: '#FFFFFF',
          foreground: '#0F172A',
        },
        muted: {
          DEFAULT: '#F8FAFC',
          foreground: '#64748B',
        },
        border: '#E2E8F0',
        input: '#E2E8F0',
        ring: '#6366F1',
      },
      fontFamily: {
        heading: ['Outfit', 'sans-serif'],
        body: ['Plus Jakarta Sans', 'sans-serif'],
      },
      borderRadius: {
        lg: '0.75rem',
        md: '0.5rem',
        sm: '0.25rem',
      },
      boxShadow: {
        'neo': '3px 3px 0px 0px #0F172A',
        'neo-lg': '5px 5px 0px 0px #0F172A',
        'neo-button': '2px 2px 0px 0px #0F172A',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}
