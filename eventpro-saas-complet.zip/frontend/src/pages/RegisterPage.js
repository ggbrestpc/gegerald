// Page d'inscription
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    companyName: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await register(
      formData.email,
      formData.password,
      formData.fullName,
      formData.companyName
    );
    
    if (result.success) {
      toast.success('✅ Compte créé avec succès !');
      navigate('/dashboard');
    } else {
      toast.error(result.error || '❌ Erreur lors de l\'inscription');
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="neo-card p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/">
              <h1 className="text-3xl font-heading font-extrabold gradient-text">
                🎫 EventPro
              </h1>
            </Link>
            <p className="text-slate-600 mt-2">Créez votre compte</p>
          </div>

          {/* Formulaire */}
          <form onSubmit={handleSubmit} className="space-y-5" data-testid="register-form">
            <div>
              <Label htmlFor="fullName">Nom complet</Label>
              <Input
                id="fullName"
                type="text"
                placeholder="Jean Dupont"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                required
                className="mt-2 bg-slate-50 border-2 border-slate-200 focus:border-primary"
                data-testid="register-fullname-input"
              />
            </div>

            <div>
              <Label htmlFor="companyName">Nom de l'entreprise (optionnel)</Label>
              <Input
                id="companyName"
                type="text"
                placeholder="Mon Entreprise"
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="mt-2 bg-slate-50 border-2 border-slate-200 focus:border-primary"
                data-testid="register-company-input"
              />
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="vous@exemple.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="mt-2 bg-slate-50 border-2 border-slate-200 focus:border-primary"
                data-testid="register-email-input"
              />
            </div>

            <div>
              <Label htmlFor="password">Mot de passe</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
                minLength={6}
                className="mt-2 bg-slate-50 border-2 border-slate-200 focus:border-primary"
                data-testid="register-password-input"
              />
              <p className="text-xs text-slate-500 mt-1">Minimum 6 caractères</p>
            </div>

            <Button
              type="submit"
              className="w-full neo-button neo-button-primary text-lg py-6"
              disabled={loading}
              data-testid="register-submit-button"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Création...
                </>
              ) : (
                'Créer mon compte'
              )}
            </Button>
          </form>

          {/* Lien connexion */}
          <div className="mt-6 text-center">
            <p className="text-slate-600">
              Déjà un compte ?{' '}
              <Link 
                to="/login" 
                className="text-primary font-bold hover:underline"
                data-testid="login-link"
              >
                Connectez-vous
              </Link>
            </p>
          </div>
        </div>

        {/* Retour accueil */}
        <div className="mt-6 text-center">
          <Link 
            to="/" 
            className="text-slate-600 hover:text-slate-900 font-medium"
          >
            ← Retour à l'accueil
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
