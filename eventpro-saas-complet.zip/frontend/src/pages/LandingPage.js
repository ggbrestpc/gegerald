// Page d'accueil (Landing Page) marketing
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  Ticket, 
  QrCode, 
  Palette, 
  Zap, 
  TrendingUp,
  Check,
  ArrowRight
} from 'lucide-react';

export default function LandingPage() {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Calendar className="w-8 h-8" />,
      title: "Gestion d'événements",
      description: "Créez et gérez vos événements en quelques clics avec une interface intuitive",
      color: "bg-purple-500"
    },
    {
      icon: <Ticket className="w-8 h-8" />,
      title: "Billetterie intégrée",
      description: "Vendez vos places en ligne avec paiement sécurisé via Stripe",
      color: "bg-pink-500"
    },
    {
      icon: <QrCode className="w-8 h-8" />,
      title: "QR Codes sécurisés",
      description: "Chaque billet génère un QR code unique pour un contrôle d'accès facile",
      color: "bg-blue-500"
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: "Personnalisation complète",
      description: "Choisissez vos couleurs, thèmes et personnalisez vos pages événements",
      color: "bg-teal-500"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Intégration facile",
      description: "Intégrez vos événements sur n'importe quel site via webhook",
      color: "bg-amber-500"
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "SEO optimisé",
      description: "Génération automatique de pages SEO pour maximiser votre visibilité",
      color: "bg-lime-500"
    }
  ];

  const plans = [
    {
      name: "Starter",
      price: "39€",
      period: "/ mois",
      features: [
        "1 site web",
        "20 événements",
        "Billetterie illimitée",
        "QR Codes sécurisés",
        "Support email"
      ],
      color: "border-purple-500",
      buttonColor: "bg-purple-500 hover:bg-purple-600"
    },
    {
      name: "Professional",
      price: "99€",
      period: "/ mois",
      popular: true,
      features: [
        "3 sites web",
        "100 événements",
        "Billetterie illimitée",
        "QR Codes sécurisés",
        "Thèmes premium",
        "Webhooks personnalisés",
        "Support prioritaire"
      ],
      color: "border-pink-500",
      buttonColor: "bg-pink-500 hover:bg-pink-600"
    },
    {
      name: "Enterprise",
      price: "249€",
      period: "/ mois",
      features: [
        "Sites illimités",
        "Événements illimités",
        "Tout du Professional",
        "API complète",
        "White label",
        "Support dédié 24/7"
      ],
      color: "border-blue-500",
      buttonColor: "bg-blue-500 hover:bg-blue-600"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b-2 border-slate-900 bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.h1 
            className="text-2xl font-heading font-extrabold"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <span className="gradient-text">🎫 EventPro</span>
          </motion.h1>
          <div className="flex gap-3">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/login')}
              data-testid="header-login-button"
            >
              Connexion
            </Button>
            <Button 
              className="neo-button neo-button-primary"
              onClick={() => navigate('/register')}
              data-testid="header-register-button"
            >
              Commencer
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
        <div className="container mx-auto px-4">
          <motion.div 
            className="max-w-4xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-5xl md:text-7xl font-heading font-extrabold mb-6 leading-tight">
              Créez des événements
              <br />
              <span className="gradient-text">inoubliables</span>
            </h2>
            <p className="text-xl md:text-2xl text-slate-600 mb-8 max-w-2xl mx-auto font-medium">
              La plateforme SaaS tout-en-un pour gérer vos événements, vendre vos billets et offrir une expérience unique à vos participants
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                className="neo-button neo-button-primary text-lg px-8 py-6"
                onClick={() => navigate('/register')}
                data-testid="hero-cta-button"
              >
                Démarrer gratuitement
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="neo-button neo-button-secondary text-lg px-8 py-6"
                data-testid="hero-demo-button"
              >
                Voir la démo
              </Button>
            </div>
          </motion.div>
        </div>
        
        {/* Décorations */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-purple-400 rounded-full opacity-20 animate-float"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-pink-400 rounded-full opacity-20 animate-float" style={{animationDelay: '1s'}}></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white" data-testid="features-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-heading font-bold mb-4">
              Tout ce dont vous avez besoin
            </h2>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Une suite complète d'outils pour réussir vos événements
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="neo-card p-8"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                data-testid={`feature-card-${index}`}
              >
                <div className={`${feature.color} w-16 h-16 rounded-xl flex items-center justify-center text-white mb-4`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-heading font-bold mb-2">
                  {feature.title}
                </h3>
                <p className="text-slate-600">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-slate-50" data-testid="pricing-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-heading font-bold mb-4">
              Choisissez votre plan
            </h2>
            <p className="text-xl text-slate-600">
              Des tarifs simples et transparents pour tous
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <motion.div
                key={index}
                className={`neo-card p-8 relative ${
                  plan.popular ? 'border-4 scale-105' : ''
                } ${plan.color}`}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: plan.popular ? 1.05 : 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                data-testid={`pricing-card-${plan.name.toLowerCase()}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-pink-500 text-white px-4 py-1 rounded-full text-sm font-bold">
                      POPULAIRE
                    </span>
                  </div>
                )}
                
                <h3 className="text-2xl font-heading font-bold mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-5xl font-heading font-extrabold">{plan.price}</span>
                  <span className="text-slate-600">{plan.period}</span>
                </div>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full ${plan.buttonColor} text-white font-bold py-6 rounded-xl border-2 border-slate-900 shadow-neo-button hover:shadow-neo-lg hover:-translate-y-1 transition-all`}
                  onClick={() => navigate('/register')}
                  data-testid={`plan-button-${plan.name.toLowerCase()}`}
                >
                  Commencer
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-6xl font-heading font-extrabold mb-6">
              Prêt à commencer ?
            </h2>
            <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-2xl mx-auto">
              Rejoignez des centaines d'organisateurs qui font confiance à EventPro
            </p>
            <Button 
              size="lg" 
              className="bg-white text-purple-600 hover:bg-slate-100 font-bold text-lg px-10 py-7 rounded-xl border-2 border-white shadow-neo-button hover:shadow-neo-lg hover:-translate-y-1 transition-all"
              onClick={() => navigate('/register')}
              data-testid="cta-button"
            >
              Créer mon compte gratuitement
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-slate-900 bg-white py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-600">
            © 2024 EventPro. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  );
}
