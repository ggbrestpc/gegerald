// Page événement publique
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, Clock, Users, Ticket } from 'lucide-react';
import api from '@/utils/api';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

export default function PublicEventPage() {
  const { eventSlug } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvent();
  }, [eventSlug]);

  const fetchEvent = async () => {
    try {
      // Route publique sans authentification
      const response = await axios.get(
        `${BACKEND_URL}/api/events/public/event/${eventSlug}`
      );
      setEvent(response.data);
    } catch (error) {
      console.error('Erreur:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-heading font-bold mb-4">Événement non trouvé</h1>
          <p className="text-slate-600">Cet événement n'existe pas ou n'est plus disponible.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Image */}
      <div 
        className="h-96 bg-gradient-to-br from-purple-600 to-pink-600 relative"
        style={{
          backgroundImage: event.cover_image ? `url(${event.cover_image})` : 'none',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="container mx-auto px-4 h-full flex items-end pb-12 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-white"
          >
            <h1 className="text-5xl md:text-6xl font-heading font-extrabold mb-4">
              {event.title}
            </h1>
            <div className="flex flex-wrap gap-4 text-lg">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                {formatDate(event.start_date)}
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                {event.city}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Description */}
          <div className="lg:col-span-2">
            <div className="neo-card p-8">
              <h2 className="text-3xl font-heading font-bold mb-6">À propos</h2>
              <p className="text-lg text-slate-700 whitespace-pre-line">
                {event.description}
              </p>

              {/* Infos pratiques */}
              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <Calendar className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-bold">Date et heure</div>
                    <div className="text-slate-600">
                      Du {formatDate(event.start_date)}<br />
                      Au {formatDate(event.end_date)}
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-bold">Lieu</div>
                    <div className="text-slate-600">
                      {event.location}<br />
                      {event.address}<br />
                      {event.postal_code} {event.city}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Billetterie */}
          <div>
            <div className="neo-card p-6 sticky top-6">
              <h3 className="text-2xl font-heading font-bold mb-6">Billetterie</h3>
              
              {event.price_options && event.price_options.length > 0 ? (
                <div className="space-y-4">
                  {event.price_options.map((option, index) => (
                    <div 
                      key={index}
                      className="border-2 border-slate-200 rounded-xl p-4 hover:border-primary transition-colors"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="font-bold text-lg">{option.name}</div>
                          {option.description && (
                            <div className="text-sm text-slate-600">{option.description}</div>
                          )}
                        </div>
                        <div className="text-2xl font-heading font-bold text-primary">
                          {option.price}€
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
                        <Users className="w-4 h-4" />
                        {option.available_seats - option.sold_seats} places disponibles
                      </div>
                      <Button 
                        className="w-full neo-button neo-button-primary"
                        style={{
                          backgroundColor: event.button_color,
                          borderColor: event.button_color
                        }}
                      >
                        {event.button_text || 'Réserver'}
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-600">Billetterie non disponible</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
