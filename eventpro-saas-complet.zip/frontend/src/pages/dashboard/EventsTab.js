// Onglet de gestion des événements
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  Plus, 
  Calendar, 
  MapPin, 
  Edit, 
  Trash2, 
  Eye,
  ExternalLink
} from 'lucide-react';
import api from '@/utils/api';
import { toast } from 'sonner';
import CreateEventDialog from './CreateEventDialog';

export default function EventsTab() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await api.get('/events/');
      setEvents(response.data);
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du chargement des événements');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (eventId) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer cet événement ?')) {
      return;
    }

    try {
      await api.delete(`/events/${eventId}`);
      toast.success('Événement supprimé');
      fetchEvents();
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  return (
    <div data-testid="events-tab">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-2xl font-heading font-bold">Mes Événements</h3>
          <p className="text-slate-600">Créez et gérez vos événements</p>
        </div>
        <Button
          onClick={() => setShowCreateDialog(true)}
          className="neo-button neo-button-primary"
          data-testid="create-event-button"
        >
          <Plus className="w-5 h-5 mr-2" />
          Nouvel événement
        </Button>
      </div>

      {/* Events List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="mt-4 text-slate-600">Chargement...</p>
        </div>
      ) : events.length === 0 ? (
        <div className="text-center py-12" data-testid="no-events-message">
          <Calendar className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h4 className="text-xl font-bold text-slate-900 mb-2">
            Aucun événement pour le moment
          </h4>
          <p className="text-slate-600 mb-6">
            Commencez par créer votre premier événement
          </p>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="neo-button neo-button-primary"
          >
            <Plus className="w-5 h-5 mr-2" />
            Créer mon premier événement
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              className="neo-card p-0 overflow-hidden group"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              data-testid={`event-card-${index}`}
            >
              {/* Image */}
              <div className="h-48 bg-gradient-to-br from-purple-400 to-pink-400 relative overflow-hidden">
                {event.cover_image ? (
                  <img 
                    src={event.cover_image} 
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Calendar className="w-16 h-16 text-white opacity-50" />
                  </div>
                )}
                <div className="absolute top-3 right-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    event.is_published 
                      ? 'bg-green-500 text-white' 
                      : 'bg-yellow-500 text-white'
                  }`}>
                    {event.is_published ? 'Publié' : 'Brouillon'}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h4 className="text-xl font-heading font-bold mb-2 line-clamp-1">
                  {event.title}
                </h4>
                
                <div className="space-y-2 mb-4 text-sm text-slate-600">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(event.start_date)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span className="line-clamp-1">{event.city}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    data-testid={`view-event-button-${index}`}
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Voir
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    data-testid={`edit-event-button-${index}`}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-600 hover:bg-red-50"
                    onClick={() => handleDelete(event.id)}
                    data-testid={`delete-event-button-${index}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Create Event Dialog */}
      {showCreateDialog && (
        <CreateEventDialog
          open={showCreateDialog}
          onClose={() => setShowCreateDialog(false)}
          onSuccess={() => {
            setShowCreateDialog(false);
            fetchEvents();
          }}
        />
      )}
    </div>
  );
}
