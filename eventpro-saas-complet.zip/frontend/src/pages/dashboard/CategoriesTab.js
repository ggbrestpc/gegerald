// Onglet de gestion des catégories
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Palette, Edit, Trash2 } from 'lucide-react';
import api from '@/utils/api';
import { toast } from 'sonner';

export default function CategoriesTab() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    color: '#6366F1',
    description: ''
  });

  const predefinedColors = [
    { name: 'Violet', value: '#6366F1' },
    { name: 'Rose', value: '#F43F5E' },
    { name: 'Bleu', value: '#3B82F6' },
    { name: 'Vert', value: '#84CC16' },
    { name: 'Orange', value: '#F59E0B' },
    { name: 'Violet foncé', value: '#A855F7' },
    { name: 'Cyan', value: '#14B8A6' },
    { name: 'Rose foncé', value: '#EC4899' },
  ];

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/events/categories');
      setCategories(response.data);
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du chargement des catégories');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await api.post('/events/categories', formData);
      toast.success('✅ Catégorie créée !');
      setShowForm(false);
      setFormData({ name: '', slug: '', color: '#6366F1', description: '' });
      fetchCategories();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erreur lors de la création');
    }
  };

  const handleDelete = async (categoryId) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')) {
      return;
    }

    try {
      await api.delete(`/events/categories/${categoryId}`);
      toast.success('Catégorie supprimée');
      fetchCategories();
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const generateSlug = (name) => {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const handleNameChange = (name) => {
    setFormData({
      ...formData,
      name,
      slug: generateSlug(name)
    });
  };

  return (
    <div data-testid="categories-tab">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-2xl font-heading font-bold">Catégories</h3>
          <p className="text-slate-600">Organisez vos événements par catégories</p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="neo-button neo-button-primary"
          data-testid="create-category-button"
        >
          <Plus className="w-5 h-5 mr-2" />
          Nouvelle catégorie
        </Button>
      </div>

      {/* Form */}
      {showForm && (
        <motion.div
          className="bg-slate-50 border-2 border-slate-200 rounded-xl p-6 mb-6"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          data-testid="category-form"
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nom de la catégorie</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="Musique, Sport, Conférence..."
                  required
                  className="mt-2"
                  data-testid="category-name-input"
                />
              </div>
              <div>
                <Label htmlFor="slug">Slug (URL)</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  placeholder="musique"
                  required
                  className="mt-2"
                  data-testid="category-slug-input"
                />
              </div>
            </div>

            <div>
              <Label>Couleur</Label>
              <div className="grid grid-cols-4 md:grid-cols-8 gap-3 mt-2">
                {predefinedColors.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    onClick={() => setFormData({ ...formData, color: color.value })}
                    className={`w-12 h-12 rounded-xl border-2 transition-all ${
                      formData.color === color.value
                        ? 'border-slate-900 scale-110 shadow-neo'
                        : 'border-slate-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: color.value }}
                    title={color.name}
                    data-testid={`color-${color.name.toLowerCase()}`}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                type="submit"
                className="neo-button neo-button-primary"
                data-testid="submit-category-button"
              >
                Créer
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowForm(false)}
              >
                Annuler
              </Button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Categories List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : categories.length === 0 ? (
        <div className="text-center py-12" data-testid="no-categories-message">
          <Palette className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h4 className="text-xl font-bold text-slate-900 mb-2">
            Aucune catégorie pour le moment
          </h4>
          <p className="text-slate-600">
            Créez votre première catégorie pour organiser vos événements
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map((category, index) => (
            <motion.div
              key={category.id}
              className="neo-card p-5 flex items-center gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              data-testid={`category-card-${index}`}
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: category.color }}
              >
                <Palette className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg">{category.name}</h4>
                <p className="text-sm text-slate-600">/{category.slug}</p>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="text-red-600 hover:bg-red-50"
                onClick={() => handleDelete(category.id)}
                data-testid={`delete-category-button-${index}`}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
