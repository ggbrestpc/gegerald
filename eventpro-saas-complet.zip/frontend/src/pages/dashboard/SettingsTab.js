// Onglet des paramètres
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { User, CreditCard, Webhook, Key } from 'lucide-react';

export default function SettingsTab() {
  const { user } = useAuth();

  return (
    <div className="space-y-8" data-testid="settings-tab">
      {/* Profil */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <User className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-heading font-bold">Profil</h3>
        </div>
        <div className="space-y-4 max-w-xl">
          <div>
            <Label>Nom complet</Label>
            <Input 
              value={user?.full_name || ''} 
              className="mt-2"
              disabled
            />
          </div>
          <div>
            <Label>Email</Label>
            <Input 
              value={user?.email || ''} 
              className="mt-2"
              disabled
            />
          </div>
          <div>
            <Label>Entreprise</Label>
            <Input 
              value={user?.company_name || ''} 
              className="mt-2"
              placeholder="Votre entreprise"
            />
          </div>
        </div>
      </div>

      {/* Abonnement */}
      <div className="border-t-2 border-slate-200 pt-8">
        <div className="flex items-center gap-3 mb-6">
          <CreditCard className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-heading font-bold">Abonnement</h3>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-xl p-6 max-w-xl">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="text-sm text-slate-600 mb-1">Plan actuel</div>
              <div className="text-2xl font-heading font-bold text-purple-600">
                {user?.subscription_plan || 'Gratuit'}
              </div>
            </div>
            <span className={`px-3 py-1 rounded-full text-sm font-bold ${
              user?.subscription_status === 'active' 
                ? 'bg-green-500 text-white'
                : 'bg-slate-300 text-slate-700'
            }`}>
              {user?.subscription_status === 'active' ? 'Actif' : 'Inactif'}
            </span>
          </div>
          <div className="space-y-2 text-sm text-slate-600 mb-6">
            <div>🌐 Sites: {user?.sites_limit === 999999 ? 'Illimités' : user?.sites_limit || 0}</div>
            <div>🎫 Événements: {user?.events_limit === 999999 ? 'Illimités' : user?.events_limit || 0}</div>
          </div>
          <Button className="neo-button neo-button-primary w-full">
            Changer de plan
          </Button>
        </div>
      </div>

      {/* Webhooks Stripe */}
      <div className="border-t-2 border-slate-200 pt-8">
        <div className="flex items-center gap-3 mb-6">
          <Webhook className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-heading font-bold">Webhooks personnalisés</h3>
        </div>
        <p className="text-slate-600 mb-4 max-w-2xl">
          Configurez des webhooks pour recevoir des notifications lors des paiements et réservations.
        </p>
        <div className="max-w-xl">
          <Label>URL du webhook</Label>
          <Input 
            placeholder="https://votre-site.com/webhook"
            className="mt-2"
          />
          <Button className="mt-4 neo-button neo-button-primary">
            Enregistrer le webhook
          </Button>
        </div>
      </div>

      {/* API Keys */}
      <div className="border-t-2 border-slate-200 pt-8">
        <div className="flex items-center gap-3 mb-6">
          <Key className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-heading font-bold">Clés API Stripe</h3>
        </div>
        <p className="text-slate-600 mb-4 max-w-2xl">
          Configurez vos clés Stripe dans le fichier <code className="bg-slate-100 px-2 py-1 rounded">backend/config.json</code>
        </p>
      </div>
    </div>
  );
}
