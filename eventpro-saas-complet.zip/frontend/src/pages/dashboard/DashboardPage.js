// Dashboard Client - Page principale
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  Ticket, 
  Users, 
  TrendingUp,
  Plus,
  Settings,
  LogOut,
  Palette,
  Link as LinkIcon,
  CreditCard
} from 'lucide-react';
import api from '@/utils/api';
import { toast } from 'sonner';
import EventsTab from './EventsTab';
import CategoriesTab from './CategoriesTab';
import SettingsTab from './SettingsTab';

export default function DashboardPage() {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('events');
  const [stats, setStats] = useState({
    totalEvents: 0,
    totalBookings: 0,
    revenue: 0
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      // Récupérer les statistiques
      const eventsResponse = await api.get('/events/');
      const events = eventsResponse.data;
      
      setStats({
        totalEvents: events.length,
        totalBookings: 0, // À implémenter
        revenue: 0 // À implémenter
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des stats:', error);
    }
  };

  const handleLogout = () => {
    logout();
    toast.success('Déconnexion réussie');
    navigate('/');
  };

  const tabs = [
    { id: 'events', label: 'Événements', icon: <Calendar className="w-5 h-5" /> },
    { id: 'categories', label: 'Catégories', icon: <Palette className="w-5 h-5" /> },
    { id: 'settings', label: 'Paramètres', icon: <Settings className="w-5 h-5" /> }
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50" data-testid="dashboard-page">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white border-r-2 border-slate-900 flex flex-col z-40">
        {/* Logo */}
        <div className="p-6 border-b-2 border-slate-900">
          <h1 className="text-2xl font-heading font-extrabold gradient-text">
            🎫 EventPro
          </h1>
          <p className="text-sm text-slate-600 mt-1">{user.email}</p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-primary text-white shadow-neo-button'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
              data-testid={`tab-${tab.id}`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>

        {/* User section */}
        <div className="p-4 border-t-2 border-slate-900">
          <div className="mb-3">
            <div className="text-xs text-slate-500 mb-1">Plan actuel</div>
            <div className="font-bold text-primary">
              {user.subscription_plan || 'Gratuit'}
            </div>
            <div className="text-xs text-slate-600 mt-1">
              {user.events_limit} événements max
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full mb-2"
            onClick={() => navigate('/pricing')}
            data-testid="upgrade-button"
          >
            <CreditCard className="w-4 h-4 mr-2" />
            Upgrader
          </Button>
          <Button
            variant="ghost"
            className="w-full text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={handleLogout}
            data-testid="logout-button"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Déconnexion
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-4xl font-heading font-bold mb-2">
            Bienvenue, {user.full_name} 👋
          </h2>
          <p className="text-slate-600 text-lg">
            Gérez vos événements et suivez vos performances
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8" data-testid="stats-section">
          <motion.div
            className="neo-card p-6 bg-gradient-to-br from-purple-500 to-purple-600 text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between mb-4">
              <Calendar className="w-8 h-8" />
              <span className="text-3xl font-heading font-bold">{stats.totalEvents}</span>
            </div>
            <div className="text-lg font-medium">Événements actifs</div>
          </motion.div>

          <motion.div
            className="neo-card p-6 bg-gradient-to-br from-pink-500 to-pink-600 text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center justify-between mb-4">
              <Ticket className="w-8 h-8" />
              <span className="text-3xl font-heading font-bold">{stats.totalBookings}</span>
            </div>
            <div className="text-lg font-medium">Billets vendus</div>
          </motion.div>

          <motion.div
            className="neo-card p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8" />
              <span className="text-3xl font-heading font-bold">{stats.revenue}€</span>
            </div>
            <div className="text-lg font-medium">Revenus totaux</div>
          </motion.div>
        </div>

        {/* Tab Content */}
        <div className="neo-card p-6 min-h-[500px]">
          {activeTab === 'events' && <EventsTab />}
          {activeTab === 'categories' && <CategoriesTab />}
          {activeTab === 'settings' && <SettingsTab />}
        </div>
      </main>
    </div>
  );
}
