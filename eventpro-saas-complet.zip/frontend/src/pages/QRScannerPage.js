// Scanner QR Code PWA
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { QrCode, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import api from '@/utils/api';
import { toast } from 'sonner';

export default function QRScannerPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [scanning, setScanning] = useState(false);
  const [qrCode, setQrCode] = useState('');
  const [validationResult, setValidationResult] = useState(null);

  const handleScan = async () => {
    if (!qrCode) {
      toast.error('Veuillez entrer un code QR');
      return;
    }

    setScanning(true);
    try {
      const response = await api.post(`/payment/validate-qr/${qrCode}`);
      setValidationResult(response.data);
      
      if (response.data.status === 'validated') {
        toast.success('✅ Billet validé !');
      } else if (response.data.status === 'already_validated') {
        toast.warning('⚠️ Billet déjà utilisé');
      }
    } catch (error) {
      toast.error('QR code invalide');
      setValidationResult({ status: 'error', message: 'QR code invalide' });
    } finally {
      setScanning(false);
    }
  };

  const resetScanner = () => {
    setQrCode('');
    setValidationResult(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-4">
      <div className="container mx-auto max-w-md py-8">
        <div className="neo-card p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <QrCode className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-heading font-bold mb-2">Scanner QR</h1>
            <p className="text-slate-600">Scannez les billets pour valider l'entrée</p>
          </div>

          {/* Scanner */}
          {!validationResult ? (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Code QR du billet
                </label>
                <input
                  type="text"
                  value={qrCode}
                  onChange={(e) => setQrCode(e.target.value)}
                  placeholder="Entrez ou scannez le code"
                  className="w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:border-primary focus:outline-none"
                  autoFocus
                />
              </div>

              <Button
                onClick={handleScan}
                disabled={scanning || !qrCode}
                className="w-full neo-button neo-button-primary py-6 text-lg"
              >
                {scanning ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Vérification...
                  </>
                ) : (
                  'Valider le billet'
                )}
              </Button>
            </div>
          ) : (
            <div className="text-center">
              {/* Résultat */}
              {validationResult.status === 'validated' ? (
                <div className="mb-6">
                  <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-green-600 mb-2">
                    Billet Validé !
                  </h2>
                  <p className="text-slate-600">{validationResult.message}</p>
                </div>
              ) : (
                <div className="mb-6">
                  <XCircle className="w-20 h-20 text-red-500 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-red-600 mb-2">
                    {validationResult.status === 'already_validated' ? 'Déjà Utilisé' : 'Invalide'}
                  </h2>
                  <p className="text-slate-600">{validationResult.message}</p>
                </div>
              )}

              <Button
                onClick={resetScanner}
                className="w-full neo-button neo-button-secondary"
              >
                Scanner un autre billet
              </Button>
            </div>
          )}

          {/* Retour dashboard */}
          <div className="mt-6 text-center">
            <button
              onClick={() => navigate('/dashboard')}
              className="text-slate-600 hover:text-slate-900 font-medium"
            >
              ← Retour au dashboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
